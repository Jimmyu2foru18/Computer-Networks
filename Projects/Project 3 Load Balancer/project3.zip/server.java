import java.io.*;
import java.net.*;
import java.util.*;
import java.text.*;

public class server 
{
    private static final int PORT = 5000;
    private static final List<String> BACKEND_SERVERS = Arrays.asList("127.0.0.1:5001", "127.0.0.1:5002");
    private static int currentServerIndex = 0;

    public static void main(String[] args) 
	{
        try (ServerSocket serverSocket = new ServerSocket(PORT)) 
			{
				System.out.println("Load balancer is running on port " + PORT);

				while (true) 
				{
					Socket clientSocket = serverSocket.accept();
					new ClientHandler(clientSocket).start();
				}
			} 
			
		catch (IOException e) 
		{
            System.err.println("Error: " + e.getMessage());
        }
    }

    private static class ClientHandler extends Thread 
	{
        private Socket clientSocket;
        public ClientHandler(Socket socket) 
		{
            this.clientSocket = socket;
        }

        public void run() 
		{
            try 
				{
					BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
					PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

					String requestLine = in.readLine();
					String requestType = requestLine.split(" ")[0];
					String backendServer = getBackendServer();
					logRequest(requestType, backendServer);

					Socket backendSocket = new Socket(backendServer.split(":")[0], Integer.parseInt(backendServer.split(":")[1]));
					PrintWriter backendOut = new PrintWriter(backendSocket.getOutputStream(), true);
					BufferedReader backendIn = new BufferedReader(new InputStreamReader(backendSocket.getInputStream()));

					backendOut.println(requestLine);
					String responseLine;
					StringBuilder response = new StringBuilder();

						while ((responseLine = backendIn.readLine()) != null) 
						{
							response.append(responseLine).append("\r\n");
						}
						out.println(response.toString());

                backendIn.close();
                backendOut.close();
                backendSocket.close();
                in.close();
                out.close();
                clientSocket.close();

				} 
			catch (IOException e) 
			{
                System.err.println("handler error: " + e.getMessage());
            }
        }

        private String getBackendServer() 
		{
            String server = BACKEND_SERVERS.get(currentServerIndex);
            currentServerIndex = (currentServerIndex + 1) % BACKEND_SERVERS.size();
            return server;
        }

        private void logRequest(String requestType, String backendServer) 
		{
            String clientIp = clientSocket.getInetAddress().getHostAddress();
            int clientPort = clientSocket.getPort();
            long requestSize = requestType.length();
            long responseSize = 0;
            int statusCode = 200;
            Date now = new Date();
            String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(now);

            System.out.printf("Client IP: %s, Client Port: %d, Request Type: %s, Chosen Server: %s, Request Size: %d, Response Size: %d, Status Code: %d, Time: %s\n",
                    clientIp, clientPort, requestType, backendServer, requestSize, responseSize, statusCode, timestamp);
        }
    }
}
