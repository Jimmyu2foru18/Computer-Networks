import java.io.*;
import java.net.*;

public class client 
{
    public static void main(String[] args) 
	{
        try 
			{
            Socket socket = new Socket("127.0.0.1", 5000);
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            String request = "GET / HTTP/1.0\r\nHost: localhost\r\n\r\n";
            out.println(request);

            String responseLine;
            while ((responseLine = in.readLine()) != null) 
			{
                System.out.println(responseLine);
            }

            in.close();
            out.close();
            socket.close();
			} 
			
		catch (IOException e) 
		{
            System.err.println("Error: " + e.getMessage());
        }
    }
}
