import java.io.*;
import java.net.*;

public class backend 
{
    public static void main(String[] args) 
	{
        int port = 5001; 
        try (ServerSocket serverSocket = new ServerSocket(port)) 
			{
			System.out.println("Backend server running on port " + port);
				while (true) 
				{
					Socket clientSocket = serverSocket.accept();
					handleClient(clientSocket);
				}
			} 
		catch (IOException e) 
		{
            System.err.println("Backend server error: " + e.getMessage());
        }
    }

    private static void handleClient(Socket clientSocket) 
	{
        try 
			{
				BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
				PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

				String requestLine = in.readLine();
				System.out.println("Received request: " + requestLine);

				String response = "HTTP/1.0 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 28\r\n\r\nYou have connected successfully!";
				out.println(response);
            in.close();
            out.close();
            clientSocket.close();
			} 
		catch (IOException e) 
		{
            System.err.println("Backend handler error: " + e.getMessage());
        }
    }
}
