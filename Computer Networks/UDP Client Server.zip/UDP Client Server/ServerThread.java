import java.io.*;
import java.net.*;
import java.util.Date;

public class ServerThread extends Thread {
    private DatagramSocket socket;
    private BufferedReader in;
    private boolean running = true;

    public ServerThread() throws IOException {
        socket = new DatagramSocket(5000);
        try {
            in = new BufferedReader(new FileReader("one-liners.txt"));
        } catch (FileNotFoundException e) {
            System.out.println("Couldn't open file.");
            in = null;
        }
    }

    public void setRunning(boolean value) {
        running = value;
    }

    private String getNextQuote() {
        String returnValue = null;
        try {
            if ((returnValue = in.readLine()) == null) {
                in.close();
                running = false;
            }
        } catch (IOException e) {
            returnValue = "Error";
        }
        return returnValue;
    }

    public void run() {
        while (running) {
            try {
                byte[] buf = new byte[256];
                DatagramPacket packet = new DatagramPacket(buf, buf.length);
                socket.receive(packet);

                boolean isEmpty = true;
                for (byte b : packet.getData()) {
                    if (b != 0) {
                        isEmpty = false;
                        break;
                    }
                }

                String dString;
                if (isEmpty || in == null) {
                    dString = new Date().toString();
                } else {
                    dString = getNextQuote();
                }

                buf = dString.getBytes();
                InetAddress address = packet.getAddress();
                int port = packet.getPort();
                packet = new DatagramPacket(buf, buf.length, address, port);
                socket.send(packet);
            } catch (IOException e) {
                e.printStackTrace();
                running = false;
            }
        }
        socket.close();
    }

    @Override
    public void interrupt() {
        super.interrupt();
        if (socket != null) {
            socket.close();
        }
        if (in != null) {
            try {
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}