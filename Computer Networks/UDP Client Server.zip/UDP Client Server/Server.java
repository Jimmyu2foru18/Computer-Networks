import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Server {
    private List<ServerThread> serverThreads;

    public Server() {
        serverThreads = new ArrayList<>();
    }

    public void startServer(int numThreads) throws IOException {
        for (int i = 0; i < numThreads; i++) {
            ServerThread thread = new ServerThread();
            serverThreads.add(thread);
            thread.start();
        }
    }

    public void stopServer() {
        for (ServerThread thread : serverThreads) {
            thread.setRunning(false);
        }
    }

    public static void main(String[] args) throws IOException {
        Server server = new Server();
        server.startServer(1);
    }
}