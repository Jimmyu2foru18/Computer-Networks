import java.net.*;
import java.io.*;

class EchoServerThread extends Thread 
{
    private Socket socket;

    public EchoServerThread(Socket socket) 
	{
        this.socket = socket;
    }

    public void run() 
	{
        try (
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))
        ) 
		{
            String inputLine;
            while ((inputLine = in.readLine()) != null) 
			{
                System.out.println("-- from Client: " + inputLine);
                out.println(inputLine.toUpperCase());
            }
        } catch (IOException e) 
		{
            e.printStackTrace();
        } finally 
		{
            try 
			{
                socket.close();
            } catch (IOException e) 
			{
                e.printStackTrace();
            }
        }
    }
}