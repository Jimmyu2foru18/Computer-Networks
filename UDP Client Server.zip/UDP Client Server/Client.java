import java.io.*;
import java.net.*;

public class Client {
    public static void main(String[] args) throws IOException {
        if (args.length != 1) {
            System.out.println("Usage: java Client <hostname>");
            return;
        }

        DatagramSocket socket = new DatagramSocket();
        
        // Get the server address
        InetAddress address = InetAddress.getByName(args[0]);
        
        // Create the packet to send
        byte[] buf = new byte[256];
        DatagramPacket packet = new DatagramPacket(buf, buf.length, address, 4445);
        
        // Send the packet
        socket.send(packet);
        
        // Get response
        packet = new DatagramPacket(buf, buf.length);
        socket.receive(packet);
        
        // Display response
        String received = new String(packet.getData(), 0, packet.getLength());
        System.out.println("Quote of the Moment: " + received);
        
        socket.close();
    }
} 