import java.net.*;
import java.util.ArrayList;
import java.util.List;

public abstract class Client {
                                               //localhost for current file else hosted on ec2
    protected static final String SERVER_ADDRESS = "ec2-54-82-60-130.compute-1.amazonaws.com";
    protected static final int SERVER_PORT = 5000;
    protected static final int MAX_ATTEMPTS = 3;
    
    protected final DatagramSocket socket;
    protected final Logger logger;
    protected final String clientId;
    protected final List<Long> rtts = new ArrayList<>();
    protected int successfulPackets = 0;

    public Client(String clientId) throws SocketException {
        this.clientId = clientId;
        this.socket = new DatagramSocket();
        this.logger = new Logger(clientId);
    }

    protected abstract void start();

    protected void sendPacket(int packetNumber, int packetSize, InetAddress serverAddr) {
        try {
            Packet packet = new Packet(new byte[packetSize], packetNumber);
            
            // Measure serialization time
            long serializationStart = System.currentTimeMillis();
            byte[] data = UDPProtocol.serialize(packet);
            long serializationTime = System.currentTimeMillis() - serializationStart;
            
            // Measure actual network RTT
            long networkStart = System.currentTimeMillis();
            DatagramPacket datagramPacket = new DatagramPacket(
                data, data.length, serverAddr, SERVER_PORT);
            socket.send(datagramPacket);

            // Wait for ack
            socket.setSoTimeout(2000);
            byte[] receiveData = new byte[packetSize];
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            socket.receive(receivePacket);
            long networkTime = System.currentTimeMillis() - networkStart;
            
            rtts.add(networkTime);
            successfulPackets++;
            
            logger.logPacket(packetNumber, networkTime, true, packetSize, serializationTime);
            System.out.printf("Packet %d: Size=%d bytes, Network RTT=%dms, S-Time=%dms%n", 
                packetNumber, packetSize, networkTime, serializationTime);

        } catch (Exception e) {
            logger.logPacket(packetNumber, 0, false, packetSize, 0);
            System.out.printf("Failed to send packet %d: %s%n", packetNumber, e.getMessage());
        }
    }

    protected void printSummary() {
        double avgRtt = rtts.stream().mapToLong(Long::longValue).average().orElse(0.0);
        System.out.printf("\n=== Client %s Summary ===\n", clientId);
        System.out.printf("Successful Packets: %d\n", successfulPackets);
        System.out.printf("Average RTT: %.2f ms\n", avgRtt);
        logger.logSummary(avgRtt, successfulPackets, rtts.size());
    }

    protected void close() {
        if (socket != null) {
            socket.close();
        }
        logger.close();
    }
} 

