Overview of Java Files

UDPProtocol.java
Handles serialization and deserialization of Packet objects for UDP communication.
Ensures that packets can be converted to and from byte arrays for transmission.

Server.java
Implements a UDP server that listens for incoming packets from clients.
Processes received packets and sends acknowledgment packets back to clients.

Packet.java
Defines the Packet class, which represents the data structure for packets sent over UDP.
Contains fields for packet data, sequence number, acknowledgment status, and a unique identifier.

Logger.java
Manages logging of packet transfer details and summaries to log files.
Creates log files for each client session and records packet transmission results.

Client.java
Abstract base class for all client implementations, providing common functionality for sending packets and logging results.
Contains methods for sending packets, calculating RTT, and printing summary statistics.

Client1.java
Implements a basic UDP client that sends a small number of packets to the server.
Includes a warm-up phase to reduce initial RTT and logs the results of packet transfers.

Client2.java
Implements a large packet transfer client that sends a specified number of larger packets to the server.
Configures socket buffer sizes for optimal performance and logs the results.

Client3.java
Implements a bulk transfer client that sends a large number of packets to the server.
Monitors progress and logs the total transfer time and packet transfer statistics.