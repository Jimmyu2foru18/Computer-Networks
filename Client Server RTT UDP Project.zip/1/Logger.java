import java.io.*;
import java.util.Date;

public class Logger {
    private final PrintWriter writer;
    private final String clientId;

    public Logger(String clientId) {
        this.clientId = clientId;
        try {
            new File("log").mkdirs(); // Create log directory if it doesn't exist
            this.writer = new PrintWriter(new FileWriter("log/client" + clientId + ".log", true));
            writer.println("\n=== New Session " + new Date() + " ===");
            writer.println("\n");
            writer.flush();
        } catch (IOException e) {
            throw new RuntimeException("Failed to make the logger", e);
        }
    }

    public void logPacket(int packetNumber, long rtt, boolean success, int size, double serializationTime) {
        writer.printf("Packet %d: %d bytes, Network RTT=%dms, Serialization=%.2fms, %s%n", 
            packetNumber, size, rtt, serializationTime, success ? "SUCCESS" : "FAILED");
        writer.flush();
    }

    public void logSummary(double avgRtt, int total, int successful) {
        writer.printf("\nSummary: %d/%d packets successful, Average RTT: %.2fms%n", 
            successful, total, avgRtt);
        writer.flush();
    }

    public void close() {
        if (writer != null) writer.close();
    }
}