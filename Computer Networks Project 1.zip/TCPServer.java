import java.io.*;
import java.net.*;

public class TCPServer {
    public static void main(String[] args) {
        int port = 3000;

        new Thread(() -> startPeerDiscoveryServer(4000)).start();

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("TCP File Server is running on port " + port);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                new Thread(new FileClientHandler(clientSocket)).start();
            }
        } catch (IOException e) {
            System.err.println("Error starting the server: " + e.getMessage());
        }
    }

    private static void startPeerDiscoveryServer(int port) {
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Peer Discovery Server running on port " + port);
            while (true) {
                Socket socket = serverSocket.accept();
                new Thread(new PeerHandler(socket)).start();
            }
        } catch (IOException e) {
            System.err.println("Error starting discovery server: " + e.getMessage());
        }
    }
}

class FileClientHandler implements Runnable {
    private Socket socket;

    public FileClientHandler(Socket socket) {
        this.socket = socket;
    }

    public void run() {
        try (InputStream in = socket.getInputStream();
             FileOutputStream fos = new FileOutputStream("received_file.zip")) {

            byte[] buffer = new byte[4096];
            int bytesRead;
            long totalBytes = 0;
            long startTime = System.currentTimeMillis();

            while ((bytesRead = in.read(buffer)) != -1) {
                fos.write(buffer, 0, bytesRead);
                totalBytes += bytesRead;

                OutputStream out = socket.getOutputStream();
                out.write(1);
                out.flush();
            }

            long endTime = System.currentTimeMillis();
            System.out.println("File received successfully.");
            calculateDownloadSpeed(totalBytes, startTime, endTime);
            logTransfer("File received, Size: " + totalBytes + " bytes");

        } catch (IOException e) {
            System.err.println("Error in client communication: " + e.getMessage());
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                System.err.println("Error closing socket: " + e.getMessage());
            }
        }
    }

    private void calculateDownloadSpeed(long totalBytes, long startTime, long endTime) {
        long duration = endTime - startTime;
        double speed = (totalBytes / 1024.0) / (duration / 1000.0);
        System.out.printf("Download Speed: %.2f KB/s%n", speed);
    }

    private void logTransfer(String message) {
        try (FileWriter fw = new FileWriter("server_log.txt", true);
             PrintWriter out = new PrintWriter(fw)) {
            out.println(message);
        } catch (IOException e) {
            System.err.println("Logging error: " + e.getMessage());
        }
    }
}

class PeerHandler implements Runnable {
    private Socket socket;

    public PeerHandler(Socket socket) {
        this.socket = socket;
    }

    public void run() {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter writer = new PrintWriter(socket.getOutputStream(), true)) {

            String peerAddress = reader.readLine();
            System.out.println("Peer connected: " + peerAddress);
            writer.println("Peers: " + peerAddress);

        } catch (IOException e) {
            System.err.println("Error handling peer: " + e.getMessage());
        }
    }
}
