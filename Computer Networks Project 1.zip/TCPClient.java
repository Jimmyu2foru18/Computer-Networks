import java.io.*;
import java.net.*;

public class TCPClient {
    public static void main(String[] args) {
        String serverAddress = "localhost";
        int serverPort = 3000;
        String filePath = "C:\\Users\\jimmy\\Desktop\\test.zip";
        discoverPeers(serverAddress, 4000);

        try (Socket socket = new Socket(serverAddress, serverPort);
             FileInputStream fis = new FileInputStream(filePath);
             OutputStream out = socket.getOutputStream()) {

            byte[] buffer = new byte[4096];
            int bytesRead;
            long totalBytes = 0;
            long startTime = System.currentTimeMillis();

            while ((bytesRead = fis.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
                out.flush();
                
                InputStream in = socket.getInputStream();
                if (in.read() != 1) {
                    System.err.println("Acknowledgment not received.");
                    break;
                }

                Thread.sleep(100);
                totalBytes += bytesRead;
            }

            long endTime = System.currentTimeMillis();
            System.out.println("File sent successfully.");
            calculateUploadSpeed(totalBytes, startTime, endTime);
            logTransfer("File sent: " + filePath + ", Size: " + totalBytes + " bytes");

        } catch (IOException | InterruptedException e) {
            System.err.println("Error in client operation: " + e.getMessage());
        }
    }

    private static void calculateUploadSpeed(long totalBytes, long startTime, long endTime) {
        long duration = endTime - startTime;
        double speed = (totalBytes / 1024.0) / (duration / 1000.0);
        System.out.printf("Upload Speed: %.2f KB/s%n", speed);
    }

    private static void logTransfer(String message) {
        try (FileWriter fw = new FileWriter("client_log.txt", true);
             PrintWriter out = new PrintWriter(fw)) {
            out.println(message);
        } catch (IOException e) {
            System.err.println("Logging error: " + e.getMessage());
        }
    }

    private static void discoverPeers(String address, int port) {
        try (Socket discoverySocket = new Socket(address, port);
             PrintWriter out = new PrintWriter(discoverySocket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(discoverySocket.getInputStream()))) {

            out.println(address + ":" + port);
            String peers = in.readLine();
            System.out.println("Discovered peers: " + peers);
        } catch (IOException e) {
            System.err.println("Error during peer discovery: " + e.getMessage());
        }
    }
}
